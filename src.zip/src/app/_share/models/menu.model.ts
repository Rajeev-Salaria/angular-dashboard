export interface Menu {
    id?:number;
    image?: string;
    link?: string;
    path?: string;
  }